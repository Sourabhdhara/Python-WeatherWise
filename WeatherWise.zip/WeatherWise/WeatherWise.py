import tkinter as tk
from tkinter import ttk, messagebox
import requests
import threading
from datetime import datetime

# =========================================================
# COLOR PALETTE (matches the To-Do List app's colorful look)
# =========================================================
BG_MAIN      = "#d2dff7"   # window background (light blue)
BG_TITLE     = "#3a73dd"   # title banner (medium blue)
BG_CARD      = "#fdf2b3"   # card / listbox-style background (pale yellow)
BTN_GREEN    = "green"     # Search
BTN_BLUE     = "#1e90ff"   # Refresh
BTN_ORANGE   = "#ff8c42"   # Auto Detect
BTN_GRAY     = "#717274"   # Exit
FONT_FAMILY  = "Comic Sans MS"

# =========================================================
# Weather icon mapping (Open-Meteo WMO codes)
# =========================================================
def get_weather_icon(code):
    """Return (emoji, description) for a WMO weather code."""
    if code == 0:
        return "☀️", "Clear sky"
    elif code in (1, 2):
        return "🌤️", "Mainly clear"
    elif code == 3:
        return "☁️", "Overcast"
    elif code in (45, 48):
        return "🌫️", "Fog"
    elif code in (51, 53, 55):
        return "🌦️", "Drizzle"
    elif code in (56, 57):
        return "🌧️", "Freezing drizzle"
    elif code in (61, 63, 65):
        return "🌧️", "Rain"
    elif code in (66, 67):
        return "🌨️", "Freezing rain"
    elif code in (71, 73, 75):
        return "❄️", "Snow"
    elif code == 77:
        return "🌨️", "Snow grains"
    elif code in (80, 81, 82):
        return "🌧️", "Rain showers"
    elif code in (85, 86):
        return "❄️", "Snow showers"
    elif code == 95:
        return "⛈️", "Thunderstorm"
    elif code in (96, 99):
        return "⛈️", "Thunderstorm with hail"
    else:
        return "🌈", "Unknown"


# =========================================================
# Geolocation (IP-based)
# =========================================================
def get_location_from_ip():
    try:
        response = requests.get("http://ip-api.com/json/", timeout=10)
        data = response.json()
        if data.get("status") == "success":
            lat = data.get("lat")
            lon = data.get("lon")
            city = data.get("city")
            country = data.get("country")
            location_name = f"{city}, {country}" if city else "Unknown"
            return lat, lon, location_name
        return None, None, None
    except Exception:
        return None, None, None


# =========================================================
# Geocoding (city name -> coordinates)
# =========================================================
def geocode_city(city_name):
    try:
        url = f"https://geocoding-api.open-meteo.com/v1/search?name={city_name}&count=1&language=en&format=json"
        response = requests.get(url, timeout=10)
        data = response.json()
        if data.get("results"):
            result = data["results"][0]
            lat = result["latitude"]
            lon = result["longitude"]
            name = result.get("name", city_name)
            country = result.get("country", "")
            location_name = f"{name}, {country}" if country else name
            return lat, lon, location_name
        return None, None, None
    except Exception:
        return None, None, None


# =========================================================
# Fetch weather data from Open-Meteo
# =========================================================
def fetch_weather_data(lat, lon):
    params = {
        "latitude": lat,
        "longitude": lon,
        "current_weather": "true",
        "hourly": "temperature_2m,weathercode,windspeed_10m,relativehumidity_2m",
        "daily": "weathercode,temperature_2m_max,temperature_2m_min,windspeed_10m_max",
        "timezone": "auto",
        "forecast_days": 7,
    }
    response = requests.get("https://api.open-meteo.com/v1/forecast", params=params, timeout=15)
    return response.json()


# =========================================================
# Main Application Class
# =========================================================
class WeatherApp:
    def __init__(self, root):
        self.root = root
        self.root.title("WeatherWise")
        self.root.geometry("880x800")
        self.root.minsize(700, 600)
        self.root.config(bg=BG_MAIN)
        # --- Add Logo/Icon ---
        self.icon = tk.PhotoImage(file="cloud.png")  # your logo file
        self.root.iconphoto(True, self.icon)  # sets window icon
        # Stored data
        self.weather_raw = None
        self.current_location = "Unknown"
        self.current_lat = None
        self.current_lon = None
        self.temp_unit = "C"
        self.wind_unit = "kmh"
        self.logo = tk.PhotoImage(file = "cloud.png")


        self._setup_notebook_style()
        self._build_ui()
        self.auto_detect_location()

    # -----------------------------------------------------
    # Style setup (only the Notebook needs ttk styling —
    # every other widget below is a plain, fully-colorable
    # tk widget, same as the To-Do List app)
    # -----------------------------------------------------
    def _setup_notebook_style(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook", background=BG_MAIN, borderwidth=0)
        style.configure("TNotebook.Tab",
                         background="#aebdea", foreground="black",
                         padding=[14, 8], font=(FONT_FAMILY, 11, "bold"))
        style.map("TNotebook.Tab",
                  background=[("selected", BG_TITLE), ("active", "#8fa6e8")],
                  foreground=[("selected", "white")])

    # -----------------------------------------------------
    # Build the whole UI
    # -----------------------------------------------------
    def _build_ui(self):
        # ---- Title Label (banner, like the To-Do app) ----
        title_label = tk.Label(self.root, text=" WeatherWise",
                                font=(FONT_FAMILY, 30, "bold"),
                                bg=BG_TITLE, fg="white" , image=self.logo , compound="left")
        title_label.pack(fill="x")

        # ---- Entry Frame (city search + action buttons) ----
        entry_frame = tk.Frame(self.root, bg=BG_MAIN)
        entry_frame.pack(pady=15)

        city_label = tk.Label(entry_frame, text="Enter City:",
                               font=(FONT_FAMILY, 13, "bold"),
                               fg="black", bg=BG_MAIN, padx=5)
        city_label.pack(side="left")

        self.city_entry = tk.Entry(entry_frame, width=18,
                                    font=(FONT_FAMILY, 13, "bold"),
                                    bd=5, relief="ridge")
        self.city_entry.pack(side="left", padx=5)
        self.city_entry.bind("<Return>", lambda e: self.search_location())

        self.search_btn = tk.Button(entry_frame, text="🔍 Search",
                                     fg="white", bg=BTN_GREEN,
                                     font=(FONT_FAMILY, 10, "bold"),
                                     bd=5, relief="raised",
                                     command=self.search_location)
        self.search_btn.pack(side="left", padx=5)

        # ---- Button Frame (auto detect / refresh / exit) ----
        button_frame = tk.Frame(self.root, bg=BG_MAIN)
        button_frame.pack(pady=(0, 10))

        self.auto_btn = tk.Button(button_frame, text="📍 Auto Detect",
                                   fg="white", bg=BTN_ORANGE,
                                   font=(FONT_FAMILY, 11, "bold"),
                                   bd=5, relief="raised",
                                   command=self.auto_detect_location)
        self.auto_btn.pack(side="left", padx=5)

        self.refresh_btn = tk.Button(button_frame, text="🔄 Refresh",
                                      fg="white", bg=BTN_BLUE,
                                      font=(FONT_FAMILY, 11, "bold"),
                                      bd=5, relief="raised",
                                      command=self.refresh_weather)
        self.refresh_btn.pack(side="left", padx=5)

        self.exit_btn = tk.Button(button_frame, text="Exit ➜]",
                                   fg="white", bg=BTN_GRAY,
                                   font=(FONT_FAMILY, 11, "bold"),
                                   bd=5, relief="raised",
                                   command=self.root.quit)
        self.exit_btn.pack(side="left", padx=5)

        # ---- Unit Toggle Frame ----
        unit_frame = tk.Frame(self.root, bg=BG_MAIN)
        unit_frame.pack(pady=(0, 10))

        tk.Label(unit_frame, text="Units:", font=(FONT_FAMILY, 11, "bold"),
                  bg=BG_MAIN, fg="black").pack(side="left", padx=(0, 10))

        self.temp_unit_var = tk.StringVar(value="C")
        tk.Radiobutton(unit_frame, text="°C", variable=self.temp_unit_var, value="C",
                       font=(FONT_FAMILY, 10, "bold"), bg=BG_MAIN,
                       selectcolor=BG_CARD, command=self._on_unit_change).pack(side="left", padx=4)
        tk.Radiobutton(unit_frame, text="°F", variable=self.temp_unit_var, value="F",
                       font=(FONT_FAMILY, 10, "bold"), bg=BG_MAIN,
                       selectcolor=BG_CARD, command=self._on_unit_change).pack(side="left", padx=10)

        self.wind_unit_var = tk.StringVar(value="kmh")
        tk.Radiobutton(unit_frame, text="km/h", variable=self.wind_unit_var, value="kmh",
                       font=(FONT_FAMILY, 10, "bold"), bg=BG_MAIN,
                       selectcolor=BG_CARD, command=self._on_unit_change).pack(side="left", padx=4)
        tk.Radiobutton(unit_frame, text="mph", variable=self.wind_unit_var, value="mph",
                       font=(FONT_FAMILY, 10, "bold"), bg=BG_MAIN,
                       selectcolor=BG_CARD, command=self._on_unit_change).pack(side="left", padx=10)

        # ---- Status Label ----
        self.status_var = tk.StringVar(value="✨ Detecting your location...")
        status_label = tk.Label(self.root, textvariable=self.status_var,
                                 font=(FONT_FAMILY, 9, "italic"),
                                 bg=BG_MAIN, fg="#31456b")
        status_label.pack(pady=(0, 10))

        # ---- Notebook Tabs ----
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=15, pady=(0, 15))

        self.current_frame = tk.Frame(self.notebook, bg=BG_MAIN)
        self.notebook.add(self.current_frame, text=" 🌡️ Current ")

        self.hourly_frame = tk.Frame(self.notebook, bg=BG_MAIN)
        self.notebook.add(self.hourly_frame, text=" ⏱️ Hourly ")

        self.daily_frame = tk.Frame(self.notebook, bg=BG_MAIN)
        self.notebook.add(self.daily_frame, text=" 📅 7-Day ")

        self._build_current_tab()
        self._build_hourly_tab()
        self._build_daily_tab()
        self._show_loading()

    # -----------------------------------------------------
    # Tab builders
    # -----------------------------------------------------
    def _build_current_tab(self):
        self.location_label = tk.Label(self.current_frame, text="Location: --",
                                        font=(FONT_FAMILY, 16, "bold"),
                                        bg=BG_MAIN, fg=BG_TITLE)
        self.location_label.pack(anchor="w", padx=15, pady=(15, 0))

        self.update_time_label = tk.Label(self.current_frame, text="Last update: --",
                                           font=(FONT_FAMILY, 9), bg=BG_MAIN, fg="#31456b")
        self.update_time_label.pack(anchor="w", padx=15, pady=(0, 15))

        # Main weather card (yellow, like the To-Do listbox)
        weather_card = tk.Frame(self.current_frame, bg=BG_CARD, bd=5, relief="sunken")
        weather_card.pack(fill="x", padx=15, pady=10)

        icon_temp_frame = tk.Frame(weather_card, bg=BG_CARD)
        icon_temp_frame.pack(padx=20, pady=20)

        self.icon_label = tk.Label(icon_temp_frame, text="🌈", font=(FONT_FAMILY, 60), bg=BG_CARD)
        self.icon_label.pack(side="left", padx=(0, 30))

        temp_frame = tk.Frame(icon_temp_frame, bg=BG_CARD)
        temp_frame.pack(side="left")

        self.temp_label = tk.Label(temp_frame, text="--°C", font=(FONT_FAMILY, 34, "bold"), bg=BG_CARD)
        self.temp_label.pack(anchor="w")

        self.condition_label = tk.Label(temp_frame, text="--", font=(FONT_FAMILY, 14, "bold"), bg=BG_CARD)
        self.condition_label.pack(anchor="w")

        # Details card
        details_frame = tk.LabelFrame(self.current_frame, text="Details",
                                       font=(FONT_FAMILY, 11, "bold"),
                                       bg=BG_MAIN, fg=BG_TITLE, bd=3, relief="ridge")
        details_frame.pack(fill="x", padx=15, pady=15)

        self.wind_label = tk.Label(details_frame, text="💨 Wind: --",
                                    font=(FONT_FAMILY, 11), bg=BG_MAIN)
        self.wind_label.grid(row=0, column=0, sticky="w", pady=10, padx=15)

        self.humidity_label = tk.Label(details_frame, text="💧 Humidity: --",
                                        font=(FONT_FAMILY, 11), bg=BG_MAIN)
        self.humidity_label.grid(row=0, column=1, sticky="w", pady=10, padx=15)

        self.feels_label = tk.Label(details_frame, text="🌡️ Feels like: --",
                                     font=(FONT_FAMILY, 11), bg=BG_MAIN)
        self.feels_label.grid(row=1, column=0, sticky="w", pady=10, padx=15)

    def _build_hourly_tab(self):
        self.hourly_canvas = tk.Canvas(self.hourly_frame, highlightthickness=0, bg=BG_MAIN)
        scrollbar = ttk.Scrollbar(self.hourly_frame, orient="horizontal", command=self.hourly_canvas.xview)
        self.hourly_canvas.configure(xscrollcommand=scrollbar.set)

        scrollbar.pack(side="bottom", fill="x")
        self.hourly_canvas.pack(side="top", fill="both", expand=True, padx=10, pady=10)

        self.hourly_inner = tk.Frame(self.hourly_canvas, bg=BG_MAIN)
        self.hourly_canvas.create_window((0, 0), window=self.hourly_inner, anchor="nw")
        self.hourly_inner.bind("<Configure>",
                                lambda e: self.hourly_canvas.configure(scrollregion=self.hourly_canvas.bbox("all")))

    def _build_daily_tab(self):
        self.daily_container = tk.Frame(self.daily_frame, bg=BG_MAIN)
        self.daily_container.pack(fill="both", expand=True, padx=10, pady=10)

    def _show_loading(self):
        self.location_label.config(text="Location: Loading...")
        self.temp_label.config(text="--")
        self.condition_label.config(text="Fetching data...")
        self.wind_label.config(text="💨 Wind: --")
        self.humidity_label.config(text="💧 Humidity: --")
        self.feels_label.config(text="🌡️ Feels like: --")

        for widget in self.hourly_inner.winfo_children():
            widget.destroy()
        for widget in self.daily_container.winfo_children():
            widget.destroy()

    # -----------------------------------------------------
    # Unit conversion helpers
    # -----------------------------------------------------
    def _on_unit_change(self):
        self.temp_unit = self.temp_unit_var.get()
        self.wind_unit = self.wind_unit_var.get()
        if self.weather_raw:
            self._refresh_display_from_stored()

    def _refresh_display_from_stored(self):
        if self.weather_raw:
            self._update_current_tab()
            self._update_hourly_tab()
            self._update_daily_tab()

    def _convert_temp(self, celsius):
        if self.temp_unit == "C":
            return celsius, "°C"
        return celsius * 9 / 5 + 32, "°F"

    def _convert_wind(self, kmh):
        if self.wind_unit == "kmh":
            return kmh, "km/h"
        return kmh * 0.621371, "mph"

    # -----------------------------------------------------
    # Display updaters
    # -----------------------------------------------------
    def _update_current_tab(self):
        current = self.weather_raw.get("current_weather", {})
        if not current:
            return

        temp_c = current.get("temperature")
        wind_kmh = current.get("windspeed")
        weather_code = current.get("weathercode")
        icon, condition = get_weather_icon(weather_code)

        temp_val, temp_unit = self._convert_temp(temp_c)
        wind_val, wind_unit = self._convert_wind(wind_kmh)

        self.icon_label.config(text=icon)
        self.temp_label.config(text=f"{temp_val:.1f}{temp_unit}")
        self.condition_label.config(text=condition)
        self.wind_label.config(text=f"💨 Wind: {wind_val:.1f} {wind_unit}")

        hourly = self.weather_raw.get("hourly", {})
        times = hourly.get("time", [])
        humidities = hourly.get("relativehumidity_2m", [])
        humidity_str = "--"
        if times and humidities:
            now = datetime.now().replace(minute=0, second=0, microsecond=0)
            for i, t in enumerate(times):
                try:
                    if datetime.fromisoformat(t) >= now:
                        humidity_str = f"{humidities[i]}%"
                        break
                except Exception:
                    continue

        self.humidity_label.config(text=f"💧 Humidity: {humidity_str}")
        self.feels_label.config(text=f"🌡️ Feels like: {temp_val:.1f}{temp_unit}")
        self.location_label.config(text=f"📍 {self.current_location}")
        self.update_time_label.config(text=f"🕒 Last update: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    def _update_hourly_tab(self):
        for widget in self.hourly_inner.winfo_children():
            widget.destroy()

        hourly = self.weather_raw.get("hourly", {})
        times = hourly.get("time", [])
        temps = hourly.get("temperature_2m", [])
        winds = hourly.get("windspeed_10m", [])
        codes = hourly.get("weathercode", [])

        if not times:
            tk.Label(self.hourly_inner, text="No hourly data", bg=BG_MAIN,
                     font=(FONT_FAMILY, 11)).pack()
            return

        now = datetime.now().replace(minute=0, second=0, microsecond=0)
        start_idx = 0
        for i, t_str in enumerate(times):
            try:
                if datetime.fromisoformat(t_str) >= now:
                    start_idx = i
                    break
            except Exception:
                continue

        end_idx = min(start_idx + 12, len(times))
        for i in range(start_idx, end_idx):
            try:
                hour_label = datetime.fromisoformat(times[i]).strftime("%H:%M")
            except Exception:
                hour_label = times[i][11:16] if len(times[i]) > 11 else times[i]

            temp_c = temps[i] if i < len(temps) else None
            wind_kmh = winds[i] if i < len(winds) else None
            code = codes[i] if i < len(codes) else 0
            icon, _ = get_weather_icon(code)

            temp_val, temp_unit = self._convert_temp(temp_c) if temp_c is not None else (None, "")
            wind_val, wind_unit = self._convert_wind(wind_kmh) if wind_kmh is not None else (None, "")

            card = tk.Frame(self.hourly_inner, bg=BG_CARD, bd=4, relief="ridge")
            card.pack(side="left", padx=6, pady=8, fill="y")

            tk.Label(card, text=hour_label, font=(FONT_FAMILY, 10, "bold"), bg=BG_CARD).pack(padx=10, pady=(8, 0))
            tk.Label(card, text=icon, font=(FONT_FAMILY, 24), bg=BG_CARD).pack(pady=5)
            if temp_val is not None:
                tk.Label(card, text=f"{temp_val:.1f}{temp_unit}", font=(FONT_FAMILY, 10, "bold"), bg=BG_CARD).pack()
            if wind_val is not None:
                tk.Label(card, text=f"{wind_val:.1f}{wind_unit}", font=(FONT_FAMILY, 9),
                         bg=BG_CARD, fg="#555555").pack(pady=(0, 8))

    def _update_daily_tab(self):
        for widget in self.daily_container.winfo_children():
            widget.destroy()

        daily = self.weather_raw.get("daily", {})
        days = daily.get("time", [])
        max_temps = daily.get("temperature_2m_max", [])
        min_temps = daily.get("temperature_2m_min", [])
        winds = daily.get("windspeed_10m_max", [])
        codes = daily.get("weathercode", [])

        if not days:
            tk.Label(self.daily_container, text="No daily forecast", bg=BG_MAIN,
                     font=(FONT_FAMILY, 11)).pack()
            return

        for idx in range(min(len(days), 7)):
            try:
                dt = datetime.fromisoformat(days[idx])
                day_name = dt.strftime("%a")
                date_str = dt.strftime("%d/%m")
            except Exception:
                day_name = days[idx][:10]
                date_str = ""

            max_c = max_temps[idx] if idx < len(max_temps) else None
            min_c = min_temps[idx] if idx < len(min_temps) else None
            wind_kmh = winds[idx] if idx < len(winds) else None
            code = codes[idx] if idx < len(codes) else 0
            icon, _ = get_weather_icon(code)

            max_val, max_unit = self._convert_temp(max_c) if max_c is not None else (None, "")
            min_val, min_unit = self._convert_temp(min_c) if min_c is not None else (None, "")
            wind_val, wind_unit = self._convert_wind(wind_kmh) if wind_kmh is not None else (None, "")

            card = tk.Frame(self.daily_container, bg=BG_CARD, bd=4, relief="ridge", width=115)
            card.grid(row=0, column=idx, padx=6, pady=6, sticky="n")
            card.grid_propagate(False)

            tk.Label(card, text=day_name, font=(FONT_FAMILY, 11, "bold"), bg=BG_CARD).pack(pady=(8, 0))
            tk.Label(card, text=date_str, font=(FONT_FAMILY, 9), bg=BG_CARD, fg="#555555").pack()
            tk.Label(card, text=icon, font=(FONT_FAMILY, 30), bg=BG_CARD).pack(pady=5)

            if max_val is not None and min_val is not None:
                tk.Label(card, text=f"↑ {max_val:.1f}{max_unit}", font=(FONT_FAMILY, 10, "bold"),
                         bg=BG_CARD, fg="#c0392b").pack()
                tk.Label(card, text=f"↓ {min_val:.1f}{min_unit}", font=(FONT_FAMILY, 10, "bold"),
                         bg=BG_CARD, fg="#2471a3").pack()
            if wind_val is not None:
                tk.Label(card, text=f"💨 {wind_val:.1f}{wind_unit}", font=(FONT_FAMILY, 9),
                         bg=BG_CARD, fg="#555555").pack(pady=(0, 8))

    # -----------------------------------------------------
    # Networking & threading
    # -----------------------------------------------------
    def _fetch_and_display(self, lat, lon, location_name):
        try:
            self.root.after(0, lambda: self.status_var.set(f"Fetching weather for {location_name}..."))
            data = fetch_weather_data(lat, lon)
            self.weather_raw = data
            self.current_lat = lat
            self.current_lon = lon
            self.current_location = location_name
            self.root.after(0, self._on_fetch_success)
        except Exception as e:
            self.root.after(0, lambda: self._on_fetch_error(str(e)))

    def _on_fetch_success(self):
        self._refresh_display_from_stored()
        self.status_var.set(f"✔ Updated: {self.current_location}")
        self._set_buttons_state(True)

    def _on_fetch_error(self, error_msg):
        messagebox.showerror("Error", f"Failed to get weather data:\n{error_msg}")
        self.status_var.set(f"❌ Error: {error_msg}")
        self._set_buttons_state(True)
        self._show_loading()

    def _set_buttons_state(self, enabled):
        state = tk.NORMAL if enabled else tk.DISABLED
        self.search_btn.config(state=state)
        self.auto_btn.config(state=state)
        self.refresh_btn.config(state=state)

    def _start_weather_fetch(self, lat, lon, location_name):
        self._set_buttons_state(False)
        self._show_loading()
        threading.Thread(target=self._fetch_and_display, args=(lat, lon, location_name), daemon=True).start()

    def auto_detect_location(self):
        self.status_var.set("Detecting your location via IP...")
        self._set_buttons_state(False)

        def detect():
            lat, lon, loc_name = get_location_from_ip()
            if lat is None:
                self.root.after(0, self._on_detect_failed)
            else:
                self.root.after(0, lambda: self._start_weather_fetch(lat, lon, loc_name))

        threading.Thread(target=detect, daemon=True).start()

    def _on_detect_failed(self):
        self._set_buttons_state(True)
        messagebox.showerror("Location Error", "Could not detect location automatically.\nPlease enter a city name.")
        self.status_var.set("Auto-detection failed. Enter a city name.")

    def search_location(self):
        city = self.city_entry.get().strip()
        if not city:
            messagebox.showwarning("Warning", "⚠️ Please enter a city name.")
            return
        self.status_var.set(f"Searching for '{city}'...")
        self._set_buttons_state(False)

        def geocode_and_fetch():
            lat, lon, loc_name = geocode_city(city)
            if lat is None:
                self.root.after(0, lambda: self._on_search_failed(city))
            else:
                self.root.after(0, lambda: self._start_weather_fetch(lat, lon, loc_name))

        threading.Thread(target=geocode_and_fetch, daemon=True).start()

    def _on_search_failed(self, city):
        self._set_buttons_state(True)
        messagebox.showerror("Not Found", f"📭 Could not find city: '{city}'\nCheck spelling or try another.")
        self.status_var.set("Search failed. Try a different city name.")

    def refresh_weather(self):
        if self.current_lat is not None and self.current_lon is not None:
            self._start_weather_fetch(self.current_lat, self.current_lon, self.current_location)
        else:
            messagebox.showinfo("No Location", "No location yet. Use 'Auto Detect' or 'Search' first.")


# =========================================================
# Run Application
# =========================================================
if __name__ == "__main__":
    root = tk.Tk()
    app = WeatherApp(root)
    root.mainloop()
